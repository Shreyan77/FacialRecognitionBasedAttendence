# Event_Management

npm i

npm run start
